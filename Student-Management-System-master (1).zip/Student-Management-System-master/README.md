# Student-Management-System
This is a Desktop application using java. Use NetBeans IDE for developing

[![Student-Management-System](https://img.youtube.com/vi/BjLR0Bx8MRg/0.jpg)](https://www.youtube.com/watch?v=BjLR0Bx8MRg)
