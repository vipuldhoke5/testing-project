package bloodBankToday;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class Hover {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.edge.driver", "C:\\Users\\Nishant\\Desktop\\Automation Testing\\Browser Extension\\msedgeDriver.exe");
		Thread.sleep(2000);
		
		WebDriver driver= new EdgeDriver();
		Thread.sleep(2000);
		
		
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);	
		
		WebElement hover =driver.findElement(By.xpath("//*[@id=\"aspnetForm\"]/header/div[2]/div/div/nav/div[2]/ul/li[9]/a"));
		
		Actions action= new Actions(driver);
		
		action.moveToElement(hover).perform();		

	}

}
