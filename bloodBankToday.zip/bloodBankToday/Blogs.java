package bloodBankToday;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class Blogs {

	public static void main(String[] args) throws InterruptedException, IOException
	{
		Select s;//Globalize declare
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Nishant\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		Thread.sleep(2000);
		
		WebDriver driver= new ChromeDriver();
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);	
		
		//Click BLOOD BANK butoon
		driver.findElement(By.linkText("BLOGS")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.id("dismiss-button")).click();
		
		//Click Read More Button
		driver.findElement(By.linkText("READ MORE")).click();
		Thread.sleep(3000);
		
		//OutPut Secreenshot
		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\Nishant\\Desktop\\Automation Testing\\Eclips backup\\Webdriver_8957\\src\\bloodBankToday\\BLOGS.jpg"));
		Thread.sleep(3000);
		
		//Back To Home Page
		driver.navigate().back();

	}

}
