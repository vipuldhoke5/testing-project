package bloodBankToday;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

public class Find_Blood {

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		Select s;

		System.setProperty("webdriver.edge.driver", "C:\\Users\\Nishant\\Desktop\\Automation Testing\\Browser Extension\\msedgeDriver.exe");
		Thread.sleep(2000);
		
		WebDriver driver= new EdgeDriver();
		Thread.sleep(2000);
		
		
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);	
		
		// blood group
		driver.findElement(By.className("ui-selectmenu-text")).click();
		Thread.sleep(1000);// (hidden element is not clickable display: none;
		driver.findElement(By.id("ui-id-2")).click();
		Thread.sleep(1000);
		//Select State as Maharashtra
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]"))));
		s.selectByVisibleText("Maharashtra");
		Thread.sleep(2000);
		
		
		//Select District as Kolhapur
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]"))));
		s.selectByVisibleText("Kolhapur");
		Thread.sleep(2000);
		
		//Select Tehsil as Karvir
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboTeh\"]"))));
		s.selectByVisibleText("Karvir");
		Thread.sleep(2000);
		
		//Find Blood Button
		driver.findElement(By.cssSelector("input[type='submit'][value='Find Blood']")).click();
		Thread.sleep(2000);
		//OutPut Secreenshot
		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\Nishant\\Desktop\\Automation Testing\\Eclips backup\\Webdriver_8957\\src\\bloodBankToday\\BloodBank.jpg"));
		
		//Back To Home Page
		driver.navigate().back();


	}

}
