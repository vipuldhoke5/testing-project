package bloodBankToday;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BloodBank {

	public static void main(String[] args) throws InterruptedException 
	{
		Select s;//Globalize declare
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Nishant\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		Thread.sleep(2000);
		
		WebDriver driver= new ChromeDriver();
		Thread.sleep(2000);
		
		//URL
		driver.get("https://bloodbanktoday.com/");
		Thread.sleep(2000);	
		
		//Click BLOOD BANK butoon
		driver.findElement(By.linkText("BLOOD BANK")).click();
		
		//Select State
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboState\"]"))));
		s.selectByVisibleText("Maharashtra");
		Thread.sleep(2000);
		
		//Select Disc
		s=new Select((driver.findElement(By.xpath("//select[@id=\"ctl00_ContentPlaceHolder1_cboCity\"]"))));
		s.selectByVisibleText("Kolhapur");
		Thread.sleep(2000);
		
		//Search Button
		driver.findElement(By.cssSelector("input[type='submit'][value='Search']")).click();
		Thread.sleep(2000);
	

	}

}
