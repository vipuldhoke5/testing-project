package bloodBankToday;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.google.common.io.Files;

public class Causes {

	public static void main(String[] args) throws InterruptedException, IOException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Nishant\\Desktop\\Automation Testing\\Browser Extension\\chromeDriver.exe");
		Thread.sleep(2000);
		
		WebDriver driver= new ChromeDriver();
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
		
		//URL
				driver.get("https://bloodbanktoday.com/");
				Thread.sleep(2000);	
				
				//Click BLOOD BANK button
				driver.findElement(By.linkText("CAUSES")).click();
				Thread.sleep(3000);
				
				//Click on donate now button 
				driver.findElement(By.linkText("Donate Now")).click();
				
				// Select the amount by Other Amount
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAmount")).sendKeys("2000");
				
				//Fill The Details
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtName")).sendKeys("Nishant Bhusari");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtEmail")).sendKeys("nishantbhusari@gmail.com");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtMobile")).sendKeys("8956139963");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtCountry")).sendKeys("India");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtState")).sendKeys("Maharashtra");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtCity")).sendKeys("Nagpur");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtPinCode")).sendKeys("441106");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_txtAddress")).sendKeys("Nagpur");
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_cboDisplayType-button")).sendKeys("Hide Name In List");
				
				driver.findElement(By.id("ctl00_ContentPlaceHolder1_btnSave")).click();
				
				//OutPut Secreenshot
				File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				Files.copy(f, new File("C:\\Users\\Nishant\\Desktop\\Automation Testing\\Eclips backup\\Webdriver_8957\\src\\bloodBankToday\\DONATE NOW.jpg"));
				Thread.sleep(3000);
				

	}

}
